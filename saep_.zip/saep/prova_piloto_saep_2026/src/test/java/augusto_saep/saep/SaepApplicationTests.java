package augusto_saep.saep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaepApplicationTests {

	@Test
	void contextLoads() {
	}

}
