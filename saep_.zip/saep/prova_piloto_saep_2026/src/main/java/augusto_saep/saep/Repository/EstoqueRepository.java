package augusto_saep.saep.Repository;

import augusto_saep.saep.Model.EstoqueModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EstoqueRepository extends JpaRepository<EstoqueModel,Long> {

}

