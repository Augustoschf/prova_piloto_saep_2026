package augusto_saep.saep.Controller.e;

import augusto_saep.saep.Dto.EstoqueDto;
import augusto_saep.saep.Model.ProdutoModel;
import augusto_saep.saep.Repository.ProdutoRepository;
import augusto_saep.saep.Service.EstoqueService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class EstoqueAtualizarController {

    private final EstoqueService service;
    private final ProdutoRepository produtoRepository;

    public EstoqueAtualizarController(EstoqueService service, ProdutoRepository produtoRepository) {
        this.service = service;
        this.produtoRepository = produtoRepository;
    }

    @GetMapping("/estoqueatualizar/{id}")
    public String viewAtualizar(@PathVariable Long id, Model model){

        EstoqueDto estoqueDto = service.obterEstoque(id);
        model.addAttribute("estoqueDto",estoqueDto);
        List<ProdutoModel> listaProdutos = produtoRepository.findAll();
        model.addAttribute("produtos", listaProdutos);
        return "estoqueatualizar";
    }

}
