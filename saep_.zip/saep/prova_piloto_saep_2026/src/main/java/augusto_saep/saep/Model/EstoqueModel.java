package augusto_saep.saep.Model;

import jakarta.persistence.*;

@Entity
@Table(name="Estoque")
public class EstoqueModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name="Quantidade")
    private String quantidade;
    @ManyToOne
    @JoinColumn(name = "id_produto") // Avisa ao Hibernate que a chave estrangeira no banco se chama id_produto
    private ProdutoModel produto;

    public EstoqueModel() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public ProdutoModel getProduto() {
        return produto;
    }

    public void setProduto(ProdutoModel produto) {
        this.produto = produto;
    }
}
