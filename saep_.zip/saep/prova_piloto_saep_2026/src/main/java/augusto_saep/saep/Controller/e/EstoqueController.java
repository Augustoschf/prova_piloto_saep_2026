package augusto_saep.saep.Controller.e;


import augusto_saep.saep.Dto.EstoqueDto;
import augusto_saep.saep.Dto.RespostaDto;
import augusto_saep.saep.Service.EstoqueService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EstoqueController {

    private final EstoqueService service;

    public EstoqueController(EstoqueService service) {
        this.service = service;
    }


    @PostMapping("/estoque")
    public String cadastrar(@ModelAttribute("estoqueDto") EstoqueDto estoqueDto, Model model){

        RespostaDto mensagem = service.cadastrar(estoqueDto);

        if (!mensagem.getMensagem().equals("sucesso")) {
            // Houve erro → volta para a tela com a mensagem
            model.addAttribute("estoqueDto", estoqueDto);
            model.addAttribute("erro", mensagem.getMensagem());
            return "estoquecadastro";  // sua página de cadastro
        }

        return "redirect:/estoquelista";
    }



    @PostMapping("/estoque/{id}")
    public String atualizar(@ModelAttribute("produtoDto") EstoqueDto estoqueDto,
                            @PathVariable Long id,
                            Model model) {

        RespostaDto mensagem = service.atualizar(id, estoqueDto);

        if (!mensagem.getMensagem().equals("sucesso")) {
            model.addAttribute("estoqueDto", estoqueDto);
            model.addAttribute("erro", mensagem.getMensagem());
            return "estoqueatualizar";  // coloque aqui a view usada para editar
        }

        return "redirect:/estoquelista";
    }



    @DeleteMapping("/estoque/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id){

        RespostaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("excluido com sucesso");
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }



}
