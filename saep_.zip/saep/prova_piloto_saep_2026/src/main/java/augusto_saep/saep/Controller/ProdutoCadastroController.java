package augusto_saep.saep.Controller;


import augusto_saep.saep.Dto.ProdutoDto;
import augusto_saep.saep.Service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProdutoCadastroController {
    private final ProdutoService produtoService;

    public ProdutoCadastroController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping("/produtocadastro")
    public String viewCadastro(Model model){


        model.addAttribute("produtoDto",new ProdutoDto());



        return "produtocadastro";
    }

}
