package augusto_saep.saep.Controller;


import augusto_saep.saep.Dto.UsuarioDto;
import augusto_saep.saep.Service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UsuarioCadastroController {
    private final UsuarioService usuarioService;

    public UsuarioCadastroController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/usuariocadastro")
    public String viewCadastro(Model model){


        model.addAttribute("usuarioDto",new UsuarioDto());



        return "usuariocadastro";
    }

}
