package augusto_saep.saep.Service;


import augusto_saep.saep.Dto.LoginDto;
import augusto_saep.saep.Dto.RespostaDto;
import augusto_saep.saep.Dto.UsuarioDto;
import augusto_saep.saep.Model.UsuarioModel;
import augusto_saep.saep.Repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private List<UsuarioModel> listaUsuario = new ArrayList<UsuarioModel>();
    private Long ultimoId = 0L;

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    //--adicionar usuário
    public RespostaDto cadastrar(UsuarioDto usuarioDto){

        // Validar email único
        if (repository.existsByEmail(usuarioDto.getEmail())) {
            RespostaDto erro = new RespostaDto();
            erro.setMensagem("O e-mail informado já está cadastrado.");
            return erro;
        }


        // Validar senha
        if (usuarioDto.getSenha() == null ||
                usuarioDto.getSenha().length() < 5 ||
                !usuarioDto.getSenha().matches("^(?=.*[A-Za-z])(?=.*\\d).+$")) {

            RespostaDto erro = new RespostaDto();
            erro.setMensagem("A senha deve ter no mínimo 5 caracteres, contendo letras e números.");
            return erro;
        }


        UsuarioModel usuarioModel = new UsuarioModel();

        usuarioModel.setNome(usuarioDto.getNome());
        usuarioModel.setEmail(usuarioDto.getEmail());
        usuarioModel.setSenha(usuarioDto.getSenha());
        usuarioModel.setCpf(usuarioDto.getCpf());
        usuarioModel.setNivel(usuarioDto.getNivel());
        repository.save(usuarioModel);

        //--Retornar resposta positiva!
        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("sucesso");
        return resposta ;

    }

    //--excluir usuário
    public RespostaDto excluir(Long id){

        Optional<UsuarioModel> usuarioOP = repository.findById(id);

        if (usuarioOP.isPresent()){
            //--Significa que encontro o usuário pelo ID
            repository.delete(usuarioOP.get());
            RespostaDto resposta = new  RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("Não foi possível remover o usuário id = " + id);
        return resposta ;

    }


    //--atualizar usuário
    public RespostaDto atualizar(Long id, UsuarioDto usuarioDto){

        Optional<UsuarioModel> usuarioOP = repository.findById(id);

        if (usuarioOP.isPresent()){

            UsuarioModel usuario = usuarioOP.get();

            if (!usuario.getEmail().equals(usuarioDto.getEmail())) {
                if (repository.existsByEmail(usuarioDto.getEmail())) {
                    RespostaDto erro = new RespostaDto();
                    erro.setMensagem("Já existe outro usuário cadastrado com esse e-mail.");
                    return erro;
                }
            }


            usuario.setNome(usuarioDto.getNome());
            usuario.setEmail(usuarioDto.getEmail());
            usuario.setSenha(usuarioDto.getSenha());
            usuario.setNivel(usuarioDto.getNivel());
            usuario.setCpf(usuarioDto.getCpf());


            repository.save(usuario);

            RespostaDto resposta = new RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new RespostaDto();
        resposta.setMensagem("Não foi possível atualizar o usuário id = " + id);
        return resposta;
    }


    //--obter um unico usuário
    public UsuarioDto obterUsuario(Long id){

        UsuarioDto usuarioDto = new UsuarioDto();
        Optional<UsuarioModel> usuarioOP = repository.findById(id);

        if (usuarioOP.isPresent()){
            usuarioDto.setId(usuarioOP.get().getId());
            usuarioDto.setNome(usuarioOP.get().getNome());
            usuarioDto.setEmail(usuarioOP.get().getEmail());
            usuarioDto.setSenha(usuarioOP.get().getSenha());
            usuarioDto.setCpf(usuarioOP.get().getCpf());
            usuarioDto.setNivel(usuarioOP.get().getNivel());
            return usuarioDto;
        }
        return usuarioDto;
    }

    //--obter todos os usuários
    public List<UsuarioDto> obterUsuarios(){

        //--Criar a lista de usuarioDTO
        List<UsuarioDto> listaUsuarioDto = new ArrayList<>();

        List<UsuarioModel> listaUsuarioModel = repository.findAll();

        //--percorrer a lista de usuarioModel
        for (UsuarioModel usuario : listaUsuarioModel){
            //--Criar um objeto usuarioDTO novo
            UsuarioDto usuarioDto = new UsuarioDto();
            //--Converter os dados do usuarioModel para usuarioDto
            usuarioDto.setId(usuario.getId());
            usuarioDto.setNome(usuario.getNome());
            usuarioDto.setEmail(usuario.getEmail());
            usuarioDto.setSenha(usuario.getSenha());
            usuarioDto.setNivel(usuario.getNivel());
            usuarioDto.setCpf(usuario.getCpf());
            //--adicionar o usuarioDTO na lista de usuarioDTO
            listaUsuarioDto.add(usuarioDto);
        }
        //--retornar a lista de usuarioDTO
        return listaUsuarioDto;
    }


    public boolean validarLogin(LoginDto loginDto){
        //--buscar do banco de dados o usuário atraves do e-mail/login
        Optional<UsuarioModel> usuarioOP = repository.findByEmailAndSenha(loginDto.getEmail(),loginDto.getSenha());
        //--validar se encontrou o usuário e se a senha é igual
        if (usuarioOP.isPresent() ){
            return true;
        }
        return false;
    }
    //-- Buscar usuário pelo e-mail para salvar na sessão
    public UsuarioModel buscarPorEmail(String email) {
        // Usa o repository para encontrar o usuário.
        // Se não encontrar, retorna nulo.
        return repository.findByEmailAndSenha(email, email)
                .map(usuario -> usuario)
                .orElse(repository.findAll().stream()
                        .filter(u -> u.getEmail().equals(email))
                        .findFirst()
                        .orElse(null));
    }
}

