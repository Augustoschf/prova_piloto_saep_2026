package augusto_saep.saep.Controller;




import augusto_saep.saep.Dto.ProdutoDto;
import augusto_saep.saep.Dto.RespostaDto;
import augusto_saep.saep.Service.ProdutoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdutoController {

    private final ProdutoService service;

    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping("/produto")
    public String cadastrar(@ModelAttribute("produtoDto") ProdutoDto produtoDto, Model model){

        RespostaDto mensagem = service.cadastrar(produtoDto);

        if (!mensagem.getMensagem().equals("sucesso")) {
            // Houve erro → volta para a tela com a mensagem
            model.addAttribute("produtoDto", produtoDto);
            model.addAttribute("erro", mensagem.getMensagem());
            return "produtocadastro";  // sua página de cadastro
        }

        return "redirect:/produtolista";
    }



    @PostMapping("/produto/{id}")
    public String atualizar(@ModelAttribute("produtoDto") ProdutoDto produtoDto,
                            @PathVariable Long id,
                            Model model) {

        RespostaDto mensagem = service.atualizar(id, produtoDto);

        if (!mensagem.getMensagem().equals("sucesso")) {
            model.addAttribute("usuarioDto", produtoDto);
            model.addAttribute("erro", mensagem.getMensagem());
            return "produtoatualizar";  // coloque aqui a view usada para editar
        }

        return "redirect:/produtolista";
    }



    @DeleteMapping("/produto/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id){

        RespostaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("usuário excluido com sucesso");
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }



}
