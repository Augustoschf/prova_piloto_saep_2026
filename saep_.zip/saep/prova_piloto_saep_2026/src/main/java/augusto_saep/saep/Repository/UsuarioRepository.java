package augusto_saep.saep.Repository;


import augusto_saep.saep.Model.UsuarioModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<UsuarioModel,Long> {
     boolean existsByEmail(String email);

    Optional<UsuarioModel> findByEmailAndSenha(String email, String senha);
}

