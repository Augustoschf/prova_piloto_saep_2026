package augusto_saep.saep.Dto;

import augusto_saep.saep.Model.ProdutoModel;

public class EstoqueDto {
    private Long Id;
    private String quantidade;
    private ProdutoModel id_produto;

    public EstoqueDto() {
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public ProdutoModel getId_produto() {
        return id_produto;
    }

    public void setId_produto(ProdutoModel id_produto) {
        this.id_produto = id_produto;
    }
}
