package augusto_saep.saep.Service;


import augusto_saep.saep.Dto.EstoqueDto;
import augusto_saep.saep.Dto.RespostaDto;
import augusto_saep.saep.Model.EstoqueModel;
import augusto_saep.saep.Repository.EstoqueRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EstoqueService {

    private List<EstoqueModel> listaEstoque = new ArrayList<EstoqueModel>();
    private Long ultimoId = 0L;

    private final EstoqueRepository repository;

    public EstoqueService(EstoqueRepository repository) {
        this.repository = repository;
    }


    //--adicionar
    public RespostaDto cadastrar(EstoqueDto estoqueDto){


        EstoqueModel estoqueModel = new EstoqueModel();
        estoqueModel.setQuantidade(estoqueDto.getQuantidade());
        estoqueModel.setProduto(estoqueDto.getId_produto());
        repository.save(estoqueModel);

        //--Retornar resposta positiva!
        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("sucesso");
        return resposta ;

    }

    //--excluir
    public RespostaDto excluir(Long id){

        Optional<EstoqueModel> estoqueOP = repository.findById(id);

        if (estoqueOP.isPresent()){
            //--Significa que encontro o  ID
            repository.delete(estoqueOP.get());
            RespostaDto resposta = new  RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("Não foi possível remover id = " + id);
        return resposta ;

    }


    //--atualizar
    public RespostaDto atualizar(Long id, EstoqueDto estoqueDto){

        Optional<EstoqueModel> estoqueOP = repository.findById(id);

        if (estoqueOP.isPresent()){

            EstoqueModel estoque = estoqueOP.get();

            estoque.setProduto(estoqueDto.getId_produto() );
            estoque.setQuantidade(estoqueDto.getQuantidade());
            repository.save(estoque);

            RespostaDto resposta = new RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new RespostaDto();
        resposta.setMensagem("Não foi possível atualizar o id = " + id);
        return resposta;
    }


    //--obter um unico
    public EstoqueDto obterEstoque(Long id){

        EstoqueDto estoqueDto = new EstoqueDto();
        Optional<EstoqueModel> estoqueOP = repository.findById(id);

        if (estoqueOP.isPresent()){
            estoqueDto.setId(estoqueOP.get().getId());
            estoqueDto.setQuantidade(estoqueOP.get().getQuantidade());
            estoqueDto.setId_produto(estoqueOP.get().getProduto());
            return estoqueDto ;
        }
        return estoqueDto ;
    }

    //--obter todos
    public List<EstoqueDto> obterEstoque(){

        //--Criar a lista
        List<EstoqueDto> listaEstoqueDto = new ArrayList<>();

        List<EstoqueModel> listaEstoqueModel = repository.findAll();

        //--percorrer a lista
        for (EstoqueModel estoque : listaEstoqueModel){
            //--Criar um objeto usuarioDTO novo
            EstoqueDto estoqueDto = new EstoqueDto();
            //--Converter os dados do usuarioModel para usuarioDto
            estoqueDto.setId(estoque.getId());
            estoqueDto.setQuantidade(estoque.getQuantidade());
            estoqueDto.setId_produto(estoque.getProduto());

            //--adicionar o usuarioDTO na lista de usuarioDTO
            listaEstoqueDto.add(estoqueDto);
        }
        //--retornar a lista de usuarioDTO
        return listaEstoqueDto;
    }

}

