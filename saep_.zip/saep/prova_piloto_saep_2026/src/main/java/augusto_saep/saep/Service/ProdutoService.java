package augusto_saep.saep.Service;


import augusto_saep.saep.Dto.ProdutoDto;
import augusto_saep.saep.Dto.RespostaDto;
import augusto_saep.saep.Model.ProdutoModel;
import augusto_saep.saep.Repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    private List<ProdutoModel> listaProduto = new ArrayList<ProdutoModel>();
    private Long ultimoId = 0L;

    private final ProdutoRepository repository;

    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    //--adicionar
    public RespostaDto cadastrar(ProdutoDto produtoDto){




        ProdutoModel produtoModel = new ProdutoModel();
        produtoModel.setNome(produtoDto.getNome());
        produtoModel.setPreco(produtoDto.getPreco());
        produtoModel.setValidade(produtoDto.getValidade());
        repository.save(produtoModel);

        //--Retornar resposta positiva!
        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("sucesso");
        return resposta ;

    }

    //--excluir
    public RespostaDto excluir(Long id){

        Optional<ProdutoModel> produtoOP = repository.findById(id);

        if (produtoOP.isPresent()){
            //--Significa que encontro o  ID
            repository.delete(produtoOP.get());
            RespostaDto resposta = new  RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new  RespostaDto();
        resposta.setMensagem("Não foi possível remover o Produto id = " + id);
        return resposta ;

    }


    //--atualizar
    public RespostaDto atualizar(Long id, ProdutoDto produtoDto){

        Optional<ProdutoModel> produtoOP = repository.findById(id);

        if (produtoOP.isPresent()){

            ProdutoModel produto = produtoOP.get();


            produto.setNome(produtoDto.getNome());
            produto.setPreco(produtoDto.getPreco());
            produto.setValidade(produtoDto.getValidade());

            repository.save(produto);

            RespostaDto resposta = new RespostaDto();
            resposta.setMensagem("sucesso");
            return resposta;
        }

        RespostaDto resposta = new RespostaDto();
        resposta.setMensagem("Não foi possível atualizar o id = " + id);
        return resposta;
    }


    //--obter um unico
    public ProdutoDto obterProduto(Long id){

        ProdutoDto produtoDto = new ProdutoDto();
        Optional<ProdutoModel> produtoOP = repository.findById(id);

        if (produtoOP.isPresent()){
            produtoDto.setId(produtoOP.get().getId());
            produtoDto.setNome(produtoOP.get().getNome());
            produtoDto.setPreco(produtoOP.get().getPreco());
            produtoDto.setValidade(produtoOP.get().getValidade());
            return produtoDto;
        }
        return produtoDto;
    }

    //--obter todos
    public List<ProdutoDto> obterProduto(){

        //--Criar a lista
        List<ProdutoDto> listaProdutoDto = new ArrayList<>();

        List<ProdutoModel> listaProdutoModel = repository.findAll();

        //--percorrer a lista
        for (ProdutoModel produto : listaProdutoModel){
            //--Criar um objeto usuarioDTO novo
            ProdutoDto produtoDto = new ProdutoDto();
            //--Converter os dados do usuarioModel para usuarioDto
            produtoDto.setId(produto.getId());
            produtoDto.setNome(produto.getNome());
            produtoDto.setValidade(produto.getValidade());
            produtoDto.setPreco(produto.getPreco());
            //--adicionar o usuarioDTO na lista de usuarioDTO
            listaProdutoDto.add(produtoDto);
        }
        //--retornar a lista de usuarioDTO
        return listaProdutoDto;
    }

}

