package augusto_saep.saep.Controller;


import augusto_saep.saep.Dto.ProdutoDto;
import augusto_saep.saep.Service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;


@Controller
public class ProdutoListaController {

    private final ProdutoService service;
    public ProdutoListaController(ProdutoService service) {
        this.service = service;
    }

    @GetMapping("/produtolista")
    public String viewProdutoLista(Model model){

        List<ProdutoDto> listaDto=service.obterProduto();

        model.addAttribute("listaDto",listaDto);

        return "produtolista";
    }

}
