package augusto_saep.saep.Controller;

import augusto_saep.saep.Dto.ProdutoDto;
import augusto_saep.saep.Service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ProdutoAtualizarController {

    private final ProdutoService service;

    public ProdutoAtualizarController(ProdutoService service) {
        this.service = service;
    }

    @GetMapping("/produtoatualizar/{id}")
    public String viewAtualizar(@PathVariable Long id, Model model){

        ProdutoDto produtoDto = service.obterProduto(id);
        model.addAttribute("produtoDto",produtoDto);
        return "produtoatualizar";
    }

}
