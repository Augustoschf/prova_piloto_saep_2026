package augusto_saep.saep.Controller;

import augusto_saep.saep.Dto.LoginDto;
import augusto_saep.saep.Model.UsuarioModel;
import augusto_saep.saep.Service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    private final UsuarioService service;

    public LoginController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping("/login")
    public String viewLogin(Model model){
        LoginDto loginDto = new LoginDto();
        model.addAttribute("loginDto", loginDto);
        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("loginDto") LoginDto loginDto, HttpSession session) {
        // Colocamos o 'HttpSession session' ali nos parâmetros do método.
        // O Spring injeta isso automaticamente para nós.

        boolean valido = service.validarLogin(loginDto);

        if (valido) {
            // SE O LOGIN FOR VÁLIDO:
            // Precisamos buscar os dados desse usuário para saber o nível de acesso dele.
            // (Você pode criar um método no seu service que busca pelo email/login do DTO)
            UsuarioModel usuarioLogado = service.buscarPorEmail(loginDto.getEmail());

            // Agora guardamos as informações no "armário" da sessão:
            // 1. Guardamos o objeto do usuário inteiro (útil se quiser mostrar o nome dele na tela)
            session.setAttribute("usuarioLogado", usuarioLogado);

            // 2. Guardamos especificamente o nível de acesso (1 ou 2)
            session.setAttribute("nivelUsuarioLogado", usuarioLogado.getNivel());

            // Redireciona para a home com a sessão criada com sucesso
            return "redirect:/home";
        } else {
            // Erro no login
            return "redirect:/login?erro";
        }
    }

    // Método extra para quando o usuário quiser deslogar do sistema
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // Destrói a sessão atual do usuário limpando todos os dados
        session.invalidate();
        return "redirect:/login";
    }
}