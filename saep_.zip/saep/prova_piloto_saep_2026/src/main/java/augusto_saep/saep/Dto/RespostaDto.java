package augusto_saep.saep.Dto;

public class RespostaDto {

    private String mensagem;

    public RespostaDto() { }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}

