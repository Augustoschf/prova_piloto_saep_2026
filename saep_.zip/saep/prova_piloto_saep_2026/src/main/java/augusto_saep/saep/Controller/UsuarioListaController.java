package augusto_saep.saep.Controller;


import augusto_saep.saep.Dto.UsuarioDto;
import augusto_saep.saep.Service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

;

@Controller
public class UsuarioListaController {

    private final UsuarioService service;
    public UsuarioListaController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping("/usuariolista")
    public String viewUsuarioLista(Model model){

        List<UsuarioDto> listaDto=service.obterUsuarios();

        model.addAttribute("listaDto",listaDto);

        return "usuariolista";
    }

}
