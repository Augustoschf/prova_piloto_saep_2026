package augusto_saep.saep.Controller.e;


import augusto_saep.saep.Dto.EstoqueDto;
import augusto_saep.saep.Service.EstoqueService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;


@Controller
public class EstoqueListaController {

    private final EstoqueService service;
    public EstoqueListaController(EstoqueService service) {
        this.service = service;
    }

    @GetMapping("/estoquelista")
    public String viewEstoqueLista(Model model){

        List<EstoqueDto> listaDto=service.obterEstoque();

        model.addAttribute("listaDto",listaDto);

        return "estoquelista";
    }

}
