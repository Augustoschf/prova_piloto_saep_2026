package augusto_saep.saep.Controller;



import augusto_saep.saep.Dto.RespostaDto;
import augusto_saep.saep.Dto.UsuarioDto;
import augusto_saep.saep.Service.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @PostMapping("/usuario")
    public String cadastrar(@ModelAttribute("usuarioDto") UsuarioDto usuarioDto, Model model){

        RespostaDto mensagem = service.cadastrar(usuarioDto);

        if (!mensagem.getMensagem().equals("sucesso")) {
            // Houve erro → volta para a tela com a mensagem
            model.addAttribute("usuarioDto", usuarioDto);
            model.addAttribute("erro", mensagem.getMensagem());
            return "usuariocadastro";  // sua página de cadastro
        }

        return "redirect:/usuariolista";
    }



    @PostMapping("/usuario/{id}")
    public String atualizar(@ModelAttribute("usuarioDto") UsuarioDto usuarioDto,
                            @PathVariable Long id,
                            Model model) {

        RespostaDto mensagem = service.atualizar(id, usuarioDto);

        if (!mensagem.getMensagem().equals("sucesso")) {
            model.addAttribute("usuarioDto", usuarioDto);
            model.addAttribute("erro", mensagem.getMensagem());
            return "usuarioatualizar";  // coloque aqui a view usada para editar
        }

        return "redirect:/usuariolista";
    }



    @DeleteMapping("/usuario/{id}")
    public ResponseEntity<RespostaDto> excluir(@PathVariable Long id){

        RespostaDto resposta = service.excluir(id);

        if (resposta.getMensagem().equals("sucesso")) {
            resposta.setMensagem("usuário excluido com sucesso");
            return ResponseEntity.ok().body(resposta);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }



}
