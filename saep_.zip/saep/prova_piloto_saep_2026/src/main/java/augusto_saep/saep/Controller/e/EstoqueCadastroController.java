package augusto_saep.saep.Controller.e;


import augusto_saep.saep.Dto.EstoqueDto;
import augusto_saep.saep.Model.ProdutoModel;
import augusto_saep.saep.Repository.ProdutoRepository;
import augusto_saep.saep.Service.EstoqueService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class EstoqueCadastroController {
    private final EstoqueService estoqueService;
    private final ProdutoRepository produtoRepository;

    public EstoqueCadastroController(EstoqueService estoqueService, ProdutoRepository produtoRepository) {
        this.estoqueService = estoqueService;
        this.produtoRepository = produtoRepository;
    }

    @GetMapping("/estoquecadastro")
    public String viewCadastro(Model model){

        model.addAttribute("estoqueDto",new EstoqueDto());

        List<ProdutoModel> listaProdutos = produtoRepository.findAll();
        model.addAttribute("produtos", listaProdutos);
        return "estoquecadastro";
    }

}
